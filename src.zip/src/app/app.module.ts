import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {RouterLink,RouterLinkActive, RouterModule, Routes} from '@angular/router';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { LoginFormComponent } from './login-form/login-form.component';

const routes:Routes=[
  {path:'navbar', component:NavbarComponent},
  {path:'login', component:LoginFormComponent},
  {path:'login/signIn', component:LoginFormComponent}
];
@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    LoginFormComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
