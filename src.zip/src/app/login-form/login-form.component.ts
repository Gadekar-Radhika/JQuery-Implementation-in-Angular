import { Component, OnInit } from '@angular/core';

declare var $:any;
var isOn:boolean=false;
@Component({
  selector: 'app-login-form',
  templateUrl: './login-form.component.html',
  styleUrls: ['./login-form.component.css']
})
export class LoginFormComponent implements OnInit {

  constructor() { }
 
  //  LoginFormComponent = false;
  // loadFormComponent(){
  //      this.LoginFormComponent = true;
    // }

  ngOnInit() {
    $('.message a').click(function(){
      $('form').animate({height: "toggle", opacity: "toggle"}, "slow");
   });
  }

}
